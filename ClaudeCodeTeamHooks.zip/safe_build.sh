#!/bin/bash
# Safe build wrapper for multi-coder environments
# Acquires a per-target flock before running make.
# Usage: safe_build.sh <target> [extra make args...]
#
# If another coder is building the same target, this blocks until
# that build finishes. The loser then benefits from the freshly
# built artifacts and typically only needs to link.

BUILD_DIR="/home/leith/Desktop/URHO/New/urho3d-2.0.1/build"
LOCK_DIR="/tmp/urho_claude/locks/builds"
mkdir -p "$LOCK_DIR"

TARGET="$1"
if [ -z "$TARGET" ]; then
    echo "Usage: safe_build.sh <target> [extra make args...]" >&2
    exit 1
fi
shift

LOCK_FILE="$LOCK_DIR/${TARGET}.lock"

# flock -x: exclusive lock. Blocks until acquired.
# The lock is held for the entire duration of make.
# When make exits (success or failure), the lock releases automatically.
exec 200>"$LOCK_FILE"
if ! flock -w 600 200; then
    echo "ERROR: Could not acquire build lock for $TARGET after 10 minutes" >&2
    exit 1
fi

echo "=== Build lock acquired for $TARGET ==="
cd "$BUILD_DIR" && make -j4 "$TARGET" "$@"
EXIT_CODE=$?

# Lock releases automatically when fd 200 closes (script exit)
if [ $EXIT_CODE -eq 0 ]; then
    echo "=== Build complete: $TARGET ==="
else
    echo "=== Build FAILED: $TARGET (exit $EXIT_CODE) ==="
fi
exit $EXIT_CODE
