
#pragma once
#include <vulkan/vulkan.h>

VkResult CreateVulkanSurface(VkInstance instance, void* window, VkSurfaceKHR* surface)
{
    // Platform-specific code to create Vulkan surface (Win32/X11/Wayland/SDL2/Android/macOS)
    return VK_SUCCESS;
}
