#pragma once
#include <vulkan/vulkan.h>
#include <string>
#include <unordered_map>
#include <vector>

struct ShaderModuleInfo {
    VkShaderModule module = VK_NULL_HANDLE;
    VkShaderStageFlagBits stage;
};

class ShaderCompiler {
public:
    ShaderCompiler(VkDevice device);
    ~ShaderCompiler();

    // Compile GLSL source (or load SPIR-V) and create VkShaderModule.
    VkShaderModule CompileGLSL(const std::string& source, VkShaderStageFlagBits stage, const std::string& key);

    // Helper: get modules by key
    const std::vector<ShaderModuleInfo>& GetModules(const std::string& key) const;

private:
    VkDevice device_;
    std::unordered_map<std::string, std::vector<ShaderModuleInfo>> cache_;
};
