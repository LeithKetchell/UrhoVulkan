#include "VulkanRenderPass.h"
#include <stdexcept>
#include <iostream>

VulkanRenderPass::VulkanRenderPass(VkDevice device) : device_(device) {}

VulkanRenderPass::~VulkanRenderPass() {
    if (forward_.framebuffer) vkDestroyFramebuffer(device_, forward_.framebuffer, nullptr);
    if (forward_.renderPass) vkDestroyRenderPass(device_, forward_.renderPass, nullptr);
    if (deferred_.framebuffer) vkDestroyFramebuffer(device_, deferred_.framebuffer, nullptr);
    if (deferred_.renderPass) vkDestroyRenderPass(device_, deferred_.renderPass, nullptr);
    if (depthView_) vkDestroyImageView(device_, depthView_, nullptr);
    if (depthImage_) vkDestroyImage(device_, depthImage_, nullptr);
    if (depthMemory_) vkFreeMemory(device_, depthMemory_, nullptr);
}

bool VulkanRenderPass::CreateDepthResources(VkFormat depthFormat, VkExtent2D extent) {
    // Minimal depth image creation stub (no allocation helpers)
    std::cerr << "CreateDepthResources TODO - allocate depth image + memory" << std::endl;
    return true;
}

bool VulkanRenderPass::CreateForwardPass(VkFormat colorFormat, VkFormat depthFormat, VkExtent2D extent) {
    // Create a simple forward render pass (color + depth). Framebuffer creation is left to swapchain integration.
    VkAttachmentDescription colorAttachment{};
    colorAttachment.format = colorFormat;
    colorAttachment.samples = VK_SAMPLE_COUNT_1_BIT;
    colorAttachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    colorAttachment.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    colorAttachment.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    colorAttachment.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    colorAttachment.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    colorAttachment.finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;

    VkAttachmentDescription depthAttachment{};
    depthAttachment.format = depthFormat;
    depthAttachment.samples = VK_SAMPLE_COUNT_1_BIT;
    depthAttachment.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
    depthAttachment.storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    depthAttachment.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    depthAttachment.finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

    VkAttachmentReference colorRef{};
    colorRef.attachment = 0;
    colorRef.layout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkAttachmentReference depthRef{};
    depthRef.attachment = 1;
    depthRef.layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;

    VkSubpassDescription subpass{};
    subpass.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments = &colorRef;
    subpass.pDepthStencilAttachment = &depthRef;

    std::vector<VkAttachmentDescription> attachments = { colorAttachment, depthAttachment };

    VkRenderPassCreateInfo rpinfo{};
    rpinfo.sType = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    rpinfo.attachmentCount = static_cast<uint32_t>(attachments.size());
    rpinfo.pAttachments = attachments.data();
    rpinfo.subpassCount = 1;
    rpinfo.pSubpasses = &subpass;

    if (vkCreateRenderPass(device_, &rpinfo, nullptr, &forward_.renderPass) != VK_SUCCESS) {
        std::cerr << "Failed to create forward render pass" << std::endl;
        return false;
    }

    forward_.extent = extent;
    return true;
}

bool VulkanRenderPass::CreateDeferredPass(VkFormat colorFormat, VkFormat depthFormat, VkExtent2D extent) {
    std::cerr << "CreateDeferredPass TODO - create G-buffer attachments and render pass" << std::endl;
    deferred_.extent = extent;
    return true;
}

bool VulkanRenderPass::CreateShadowPass(VkExtent2D extent) {
    std::cerr << "CreateShadowPass TODO - create depth-only render pass for shadow maps" << std::endl;
    shadow_.extent = extent;
    return true;
}

bool VulkanRenderPass::CreatePostProcessPass(VkFormat colorFormat, VkExtent2D extent) {
    std::cerr << "CreatePostProcessPass TODO - create postprocess render pass" << std::endl;
    postProcess_.extent = extent;
    return true;
}
