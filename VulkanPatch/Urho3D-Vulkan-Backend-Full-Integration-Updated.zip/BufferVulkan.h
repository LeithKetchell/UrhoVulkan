#pragma once
#include <vulkan/vulkan.h>
#include <cstdint>

class BufferVulkan {
public:
    BufferVulkan(VkDevice device);
    ~BufferVulkan();

    bool Create(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags properties);
    void Destroy();

    VkBuffer Get() const { return buffer_; }
    VkDeviceMemory GetMemory() const { return memory_; }
private:
    VkDevice device_ = VK_NULL_HANDLE;
    VkBuffer buffer_ = VK_NULL_HANDLE;
    VkDeviceMemory memory_ = VK_NULL_HANDLE;
    VkDeviceSize size_ = 0;
};
