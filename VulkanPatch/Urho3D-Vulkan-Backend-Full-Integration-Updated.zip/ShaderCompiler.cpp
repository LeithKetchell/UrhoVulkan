#include "ShaderCompiler.h"
#include <stdexcept>
#include <iostream>

ShaderCompiler::ShaderCompiler(VkDevice device) : device_(device) {}

ShaderCompiler::~ShaderCompiler() {
    for (auto &kv : cache_) {
        for (auto &mi : kv.second) {
            if (mi.module) vkDestroyShaderModule(device_, mi.module, nullptr);
        }
    }
}

VkShaderModule ShaderCompiler::CompileGLSL(const std::string& source, VkShaderStageFlagBits stage, const std::string& key) {
    // TODO: Integrate shaderc or glslang to compile GLSL/HLSL to SPIR-V at runtime.
    // For now, this function returns VK_NULL_HANDLE and records an empty entry in the cache.
    if (cache_.count(key)) {
        for (auto &m : cache_[key]) if (m.stage == stage) return m.module;
    }
    std::cerr << "ShaderCompiler::CompileGLSL TODO - compile shader source to SPIR-V: " << key << std::endl;
    cache_[key].push_back({VK_NULL_HANDLE, stage});
    return VK_NULL_HANDLE;
}

const std::vector<ShaderModuleInfo>& ShaderCompiler::GetModules(const std::string& key) const {
    static std::vector<ShaderModuleInfo> empty;
    auto it = cache_.find(key);
    if (it == cache_.end()) return empty;
    return it->second;
}
