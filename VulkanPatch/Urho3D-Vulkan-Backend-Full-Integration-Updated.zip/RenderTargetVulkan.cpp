#include "RenderTargetVulkan.h"
#include <iostream>

RenderTargetVulkan::RenderTargetVulkan(VkDevice device) : device_(device) {}
RenderTargetVulkan::~RenderTargetVulkan() { Destroy(); }

bool RenderTargetVulkan::Create(int width, int height, VkFormat format) {
    std::cerr << "RenderTargetVulkan::Create TODO - create image, view, and framebuffer" << std::endl;
    return true;
}

void RenderTargetVulkan::Destroy() {
    if (framebuffer_) { vkDestroyFramebuffer(device_, framebuffer_, nullptr); framebuffer_ = VK_NULL_HANDLE; }
    if (view_) { vkDestroyImageView(device_, view_, nullptr); view_ = VK_NULL_HANDLE; }
    if (image_) { vkDestroyImage(device_, image_, nullptr); image_ = VK_NULL_HANDLE; }
    if (memory_) { vkFreeMemory(device_, memory_, nullptr); memory_ = VK_NULL_HANDLE; }
}
