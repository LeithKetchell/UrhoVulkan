
#pragma once
#include <vulkan/vulkan.h>

struct VulkanFrame
{
    VkCommandBuffer commandBuffer;
    VkSemaphore imageAvailableSemaphore;
    VkSemaphore renderFinishedSemaphore;
    VkFence inFlightFence;
};

void RecordAndSubmitFrame(VkDevice device, VkQueue graphicsQueue, VulkanFrame& frame)
{
    // Record commands into frame.commandBuffer
    // Submit to graphicsQueue and signal semaphores
}
