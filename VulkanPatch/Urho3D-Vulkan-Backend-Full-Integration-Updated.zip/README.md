Urho3D Vulkan Backend - Full Integration Skeleton
------------------------------------------------

This archive contains a full skeleton implementation for integrating a Vulkan
backend into Urho3D 1.9.0. The files are intentionally scaffolded with TODO
comments where engine-specific glue or third-party libraries (shaderc, VMA)
should be integrated.

Files provided:
- GraphicsVulkan.*             : main backend integrating Vulkan with Urho3D
- VulkanSwapchain.*            : swapchain management, image views, per-frame semaphores
- VulkanRenderPass.*           : forward/deferred/shadow/postpass renderpass creation
- VulkanPipeline.*             : create VkPipeline from SPIR-V modules
- ShaderCompiler.*             : runtime shader compilation stub (use shaderc/glslang)
- BufferVulkan.*               : VkBuffer helper (allocation TODO)
- TextureVulkan.*              : texture creation & upload stubs
- RenderTargetVulkan.*         : render target creation stub
- CMakeLists.txt               : example CMake for building the library

Integration notes:
1. Implement Graphics::CreateVulkanSurface using SDL_Vulkan_CreateSurface or native handles.
2. Integrate shaderc/glslang in ShaderCompiler.cpp to compile shader sources to SPIR-V.
3. Implement memory allocation (Vulkan Memory Allocator recommended) in BufferVulkan/TextureVulkan.
4. Wire GraphicsVulkan BeginFrame/EndFrame to Urho3D's render loop and use per-frame command buffers.
5. Add these sources to Urho3D's CMake and remove legacy backends if desired.

This skeleton is a starting point — it is not a complete drop-in replacement yet, but
provides the file-by-file structure and core initialization code you can expand.
