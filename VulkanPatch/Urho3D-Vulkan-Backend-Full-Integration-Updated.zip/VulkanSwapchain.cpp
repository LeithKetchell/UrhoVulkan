#include "VulkanSwapchain.h"
#include <stdexcept>
#include <vector>
#include <algorithm>
#include <iostream>

VulkanSwapchain::VulkanSwapchain(VkDevice device, VkPhysicalDevice physical, VkSurfaceKHR surface, uint32_t graphicsQueueFamily)
    : device_(device), physical_(physical), surface_(surface), graphicsQueueFamily_(graphicsQueueFamily)
{
    CreateSwapchain();
    CreateImageViews();
    CreateFrameResources();
}

VulkanSwapchain::~VulkanSwapchain()
{
    // Destroy frame resources (semaphores/fences/framebuffers)
    for (auto& f : frames_) {
        if (f.framebuffer) vkDestroyFramebuffer(device_, f.framebuffer, nullptr);
        if (f.imageAvailable) vkDestroySemaphore(device_, f.imageAvailable, nullptr);
        if (f.renderFinished) vkDestroySemaphore(device_, f.renderFinished, nullptr);
        if (f.inFlightFence) vkDestroyFence(device_, f.inFlightFence, nullptr);
    }
    for (auto view : imageViews_) if (view) vkDestroyImageView(device_, view, nullptr);
    if (swapchain_) vkDestroySwapchainKHR(device_, swapchain_, nullptr);
}

static VkSurfaceFormatKHR ChooseSurfaceFormat(const std::vector<VkSurfaceFormatKHR>& availableFormats) {
    for (const auto& f : availableFormats) {
        if (f.format == VK_FORMAT_B8G8R8A8_SRGB && f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) return f;
    }
    return availableFormats[0];
}

static VkPresentModeKHR ChoosePresentMode(const std::vector<VkPresentModeKHR>& availableModes) {
    for (const auto& m : availableModes) {
        if (m == VK_PRESENT_MODE_MAILBOX_KHR) return m;
    }
    return VK_PRESENT_MODE_FIFO_KHR;
}

void VulkanSwapchain::CreateSwapchain() {
    uint32_t formatCount = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(physical_, surface_, &formatCount, nullptr);
    if (formatCount == 0) throw std::runtime_error("No surface formats found");
    std::vector<VkSurfaceFormatKHR> formats(formatCount);
    vkGetPhysicalDeviceSurfaceFormatsKHR(physical_, surface_, &formatCount, formats.data());
    VkSurfaceFormatKHR surfaceFormat = ChooseSurfaceFormat(formats);
    format_ = surfaceFormat.format;

    VkSurfaceCapabilitiesKHR capabilities{};
    vkGetPhysicalDeviceSurfaceCapabilitiesKHR(physical_, surface_, &capabilities);

    if (capabilities.currentExtent.width == UINT32_MAX) {
        extent_.width = 640;
        extent_.height = 480;
    } else {
        extent_ = capabilities.currentExtent;
    }

    uint32_t imageCount = capabilities.minImageCount + 1;
    if (capabilities.maxImageCount > 0 && imageCount > capabilities.maxImageCount) imageCount = capabilities.maxImageCount;

    VkSwapchainCreateInfoKHR scinfo{};
    scinfo.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
    scinfo.surface = surface_;
    scinfo.minImageCount = imageCount;
    scinfo.imageFormat = surfaceFormat.format;
    scinfo.imageColorSpace = surfaceFormat.colorSpace;
    scinfo.imageExtent = extent_;
    scinfo.imageArrayLayers = 1;
    scinfo.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    scinfo.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    scinfo.preTransform = capabilities.currentTransform;
    scinfo.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    scinfo.presentMode = ChoosePresentMode({VK_PRESENT_MODE_FIFO_KHR, VK_PRESENT_MODE_MAILBOX_KHR});
    scinfo.clipped = VK_TRUE;

    if (vkCreateSwapchainKHR(device_, &scinfo, nullptr, &swapchain_) != VK_SUCCESS) {
        throw std::runtime_error("Failed to create swapchain");
    }

    uint32_t count = 0;
    vkGetSwapchainImagesKHR(device_, swapchain_, &count, nullptr);
    images_.resize(count);
    vkGetSwapchainImagesKHR(device_, swapchain_, &count, images_.data());
}

void VulkanSwapchain::CreateImageViews() {
    imageViews_.resize(images_.size());
    for (size_t i = 0; i < images_.size(); ++i) {
        VkImageViewCreateInfo viewInfo{};
        viewInfo.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        viewInfo.image = images_[i];
        viewInfo.viewType = VK_IMAGE_VIEW_TYPE_2D;
        viewInfo.format = format_;
        viewInfo.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        viewInfo.subresourceRange.baseMipLevel = 0;
        viewInfo.subresourceRange.levelCount = 1;
        viewInfo.subresourceRange.baseArrayLayer = 0;
        viewInfo.subresourceRange.layerCount = 1;
        if (vkCreateImageView(device_, &viewInfo, nullptr, &imageViews_[i]) != VK_SUCCESS) {
            throw std::runtime_error("Failed to create image view");
        }
    }
}

void VulkanSwapchain::CreateFrameResources() {
    frames_.resize(images_.size());
    // For now we only create semaphores/fences. Command buffers and framebuffers are created by the renderer.
    for (auto& f : frames_) {
        VkSemaphoreCreateInfo semInfo{};
        semInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
        if (vkCreateSemaphore(device_, &semInfo, nullptr, &f.imageAvailable) != VK_SUCCESS) throw std::runtime_error("failed to create semaphore");
        if (vkCreateSemaphore(device_, &semInfo, nullptr, &f.renderFinished) != VK_SUCCESS) throw std::runtime_error("failed to create semaphore");

        VkFenceCreateInfo fenceInfo{};
        fenceInfo.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
        fenceInfo.flags = VK_FENCE_CREATE_SIGNALED_BIT;
        if (vkCreateFence(device_, &fenceInfo, nullptr, &f.inFlightFence) != VK_SUCCESS) throw std::runtime_error("failed to create fence");
    }
}

VkResult VulkanSwapchain::AcquireNextImage(uint64_t timeout, VkSemaphore imageAvailable, uint32_t* imageIndex) {
    return vkAcquireNextImageKHR(device_, swapchain_, timeout, imageAvailable, VK_NULL_HANDLE, imageIndex);
}

void VulkanSwapchain::Recreate(uint32_t width, uint32_t height) {
    // TODO: handle swapchain recreation (wait idle, destroy old, create new)
    std::cerr << "VulkanSwapchain::Recreate - TODO" << std::endl;
}
