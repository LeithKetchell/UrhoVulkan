
#pragma once
#include <vulkan/vulkan.h>
#include "vk_mem_alloc.h"

struct VulkanMemoryManager
{
    VmaAllocator allocator;

    void Initialize(VkInstance instance, VkPhysicalDevice physicalDevice, VkDevice device)
    {
        VmaAllocatorCreateInfo allocatorInfo = {};
        allocatorInfo.physicalDevice = physicalDevice;
        allocatorInfo.device = device;
        allocatorInfo.instance = instance;
        vmaCreateAllocator(&allocatorInfo, &allocator);
    }

    void Cleanup()
    {
        vmaDestroyAllocator(allocator);
    }
};
