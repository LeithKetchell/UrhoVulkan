#include "BufferVulkan.h"
#include <iostream>

BufferVulkan::BufferVulkan(VkDevice device) : device_(device) {}
BufferVulkan::~BufferVulkan() { Destroy(); }

bool BufferVulkan::Create(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags properties) {
    size_ = size;
    VkBufferCreateInfo info{};
    info.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    info.size = size;
    info.usage = usage;
    info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    if (vkCreateBuffer(device_, &info, nullptr, &buffer_) != VK_SUCCESS) {
        std::cerr << "Failed to create buffer" << std::endl;
        return false;
    }
    // Memory allocation omitted: integrate VMA or manual allocation using vkGetBufferMemoryRequirements
    return true;
}

void BufferVulkan::Destroy() {
    if (buffer_) { vkDestroyBuffer(device_, buffer_, nullptr); buffer_ = VK_NULL_HANDLE; }
    if (memory_) { vkFreeMemory(device_, memory_, nullptr); memory_ = VK_NULL_HANDLE; }
}
