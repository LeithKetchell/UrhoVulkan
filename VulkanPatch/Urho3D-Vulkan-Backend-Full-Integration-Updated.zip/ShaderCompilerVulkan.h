
#pragma once
#include <shaderc/shaderc.hpp>
#include <vulkan/vulkan.h>
#include <vector>
#include <string>

VkShaderModule CompileShaderToSPIRV(VkDevice device, const std::string& source, shaderc_shader_kind kind)
{
    shaderc::Compiler compiler;
    shaderc::CompileOptions options;
    auto result = compiler.CompileGlslToSpv(source, kind, "shader.glsl", options);
    std::vector<uint32_t> spirv(result.cbegin(), result.cend());

    VkShaderModuleCreateInfo moduleInfo{};
    moduleInfo.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
    moduleInfo.codeSize = spirv.size() * sizeof(uint32_t);
    moduleInfo.pCode = spirv.data();

    VkShaderModule shaderModule;
    vkCreateShaderModule(device, &moduleInfo, nullptr, &shaderModule);
    return shaderModule;
}
