#pragma once
#include <vulkan/vulkan.h>
#include <vector>

class VulkanPipeline {
public:
    VulkanPipeline(VkDevice device);
    ~VulkanPipeline();

    bool Create(const std::vector<VkPipelineShaderStageCreateInfo>& stages,
                VkRenderPass renderPass,
                const VkPipelineVertexInputStateCreateInfo& vertexInput,
                const VkPipelineLayoutCreateInfo& layoutInfo,
                VkPipelineCache cache = VK_NULL_HANDLE);

    VkPipeline Get() const { return pipeline_; }
    VkPipelineLayout GetLayout() const { return layout_; }

private:
    VkDevice device_;
    VkPipeline pipeline_ = VK_NULL_HANDLE;
    VkPipelineLayout layout_ = VK_NULL_HANDLE;
};
