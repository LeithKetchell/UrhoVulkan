#pragma once
#include <vulkan/vulkan.h>

class RenderTargetVulkan {
public:
    RenderTargetVulkan(VkDevice device);
    ~RenderTargetVulkan();

    bool Create(int width, int height, VkFormat format);
    void Destroy();

    VkImage GetImage() const { return image_; }
    VkImageView GetView() const { return view_; }
    VkFramebuffer GetFramebuffer() const { return framebuffer_; }
private:
    VkDevice device_ = VK_NULL_HANDLE;
    VkImage image_ = VK_NULL_HANDLE;
    VkDeviceMemory memory_ = VK_NULL_HANDLE;
    VkImageView view_ = VK_NULL_HANDLE;
    VkFramebuffer framebuffer_ = VK_NULL_HANDLE;
};
