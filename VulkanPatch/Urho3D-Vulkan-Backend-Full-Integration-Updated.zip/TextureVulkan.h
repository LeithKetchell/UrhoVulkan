#pragma once
#include <vulkan/vulkan.h>
#include <string>

class TextureVulkan {
public:
    TextureVulkan(VkDevice device);
    ~TextureVulkan();

    bool CreateFromImageData(const void* pixels, int width, int height, VkFormat format);
    void Destroy();

    VkImageView GetView() const { return view_; }
    VkImage GetImage() const { return image_; }
private:
    VkDevice device_ = VK_NULL_HANDLE;
    VkImage image_ = VK_NULL_HANDLE;
    VkDeviceMemory memory_ = VK_NULL_HANDLE;
    VkImageView view_ = VK_NULL_HANDLE;
};
