#include "TextureVulkan.h"
#include <iostream>

TextureVulkan::TextureVulkan(VkDevice device) : device_(device) {}
TextureVulkan::~TextureVulkan() { Destroy(); }

bool TextureVulkan::CreateFromImageData(const void* pixels, int width, int height, VkFormat format) {
    std::cerr << "TextureVulkan::CreateFromImageData TODO - create VkImage and upload pixels" << std::endl;
    return true;
}

void TextureVulkan::Destroy() {
    if (view_) { vkDestroyImageView(device_, view_, nullptr); view_ = VK_NULL_HANDLE; }
    if (image_) { vkDestroyImage(device_, image_, nullptr); image_ = VK_NULL_HANDLE; }
    if (memory_) { vkFreeMemory(device_, memory_, nullptr); memory_ = VK_NULL_HANDLE; }
}
