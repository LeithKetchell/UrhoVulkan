        #include "GraphicsVulkan.h"
#include "VulkanSwapchain.h"
#include "VulkanRenderPass.h"
#include "ShaderCompiler.h"
#include "VulkanPipeline.h"
#include <stdexcept>
#include <iostream>

// Note: This file expects Urho3D's Graphics base class to provide a method:
// VkSurfaceKHR CreateVulkanSurface(VkInstance instance);
// If your Urho3D copy uses SDL, Graphics::CreateVulkanSurface should wrap SDL_Vulkan_CreateSurface.
// These functions are marked as TODO where engine-specific glue is required.

GraphicsVulkan::GraphicsVulkan() {}
GraphicsVulkan::~GraphicsVulkan() { Shutdown(); }

bool GraphicsVulkan::Initialize(bool enableValidation)
{
    if (!CreateInstance(enableValidation)) return false;
    if (!CreateSurfaceFromUrho()) return false;
    if (!PickPhysicalDevice()) return false;
    if (!CreateLogicalDevice()) return false;

    shaderCompiler_ = std::make_unique<ShaderCompiler>(device_);
    swapchain_ = std::make_unique<VulkanSwapchain>(device_, physical_, surface_, graphicsQueueFamily_);
    renderPass_ = std::make_unique<VulkanRenderPass>(device_);

    // Create default passes using swapchain formats/extent
    renderPass_->CreateForwardPass(swapchain_->GetFormat(), VK_FORMAT_D32_SFLOAT, swapchain_->GetExtent());
    renderPass_->CreateDeferredPass(swapchain_->GetFormat(), VK_FORMAT_D32_SFLOAT, swapchain_->GetExtent());
    renderPass_->CreateShadowPass({1024,1024});
    renderPass_->CreatePostProcessPass(swapchain_->GetFormat(), swapchain_->GetExtent());

    std::cout << "GraphicsVulkan initialized" << std::endl;
    return true;
}

void GraphicsVulkan::Shutdown()
{
    // Wait for device idle then destroy owned objects
    if (device_ != VK_NULL_HANDLE) vkDeviceWaitIdle(device_);

    pipelineCache_.clear();
    renderPass_.reset();
    swapchain_.reset();
    shaderCompiler_.reset();

    if (device_ != VK_NULL_HANDLE) {
        vkDestroyDevice(device_, nullptr);
        device_ = VK_NULL_HANDLE;
    }
    if (instance_ != VK_NULL_HANDLE) {
        vkDestroyInstance(instance_, nullptr);
        instance_ = VK_NULL_HANDLE;
    }
}

bool GraphicsVulkan::BeginFrame()
{
    // TODO: Acquire next image from swapchain and begin command buffer recording.
    // This is an integration point for the engine's rendering loop.
    return true;
}

void GraphicsVulkan::EndFrame()
{
    // TODO: End command buffer recording, submit to queue, and present swapchain image.
}

VulkanPipeline* GraphicsVulkan::GetPipelineForMaterial(Material* material)
{
    if (!material) return nullptr;
    // Simple hash based on material pointer + pass index; you should compute a stable hash
    size_t key = reinterpret_cast<size_t>(material);
    auto it = pipelineCache_.find(key);
    if (it != pipelineCache_.end()) return it->second;

    // Compile shaders for material (stub: material should provide shader source or filenames)
    // TODO: Query material for shader source names and compile via shaderCompiler_

    VulkanPipeline* pipe = new VulkanPipeline(device_);
    // TODO: create pipeline using compiled shader modules and appropriate render pass
    pipelineCache_[key] = pipe;
    return pipe;
}

bool GraphicsVulkan::CreateInstance(bool enableValidation)
{
    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "Urho3D-Vulkan";
    appInfo.applicationVersion = VK_MAKE_VERSION(1,0,0);
    appInfo.pEngineName = "Urho3D";
    appInfo.engineVersion = VK_MAKE_VERSION(1,0,0);
    appInfo.apiVersion = VK_API_VERSION_1_1;

    std::vector<const char*> extensions;
    // The engine (via SDL) will require platform surface extensions; enabling minimal here.
    extensions.push_back(VK_KHR_SURFACE_EXTENSION_NAME);

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;
    createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    createInfo.ppEnabledExtensionNames = extensions.data();

    if (vkCreateInstance(&createInfo, nullptr, &instance_) != VK_SUCCESS) {
        std::cerr << "Failed to create Vulkan instance" << std::endl;
        return false;
    }
    return true;
}

bool GraphicsVulkan::CreateSurfaceFromUrho()
{
    // This must be implemented by calling back into Urho3D to create a VkSurfaceKHR
    // Example: surface_ = Graphics::CreateVulkanSurface(instance_);
    // TODO: Replace the following with engine-specific glue.
    surface_ = VK_NULL_HANDLE;
    std::cerr << "GraphicsVulkan::CreateSurfaceFromUrho() - TODO: create VkSurfaceKHR from Urho3D window" << std::endl;
    return surface_ != VK_NULL_HANDLE;
}

bool GraphicsVulkan::PickPhysicalDevice()
{
    uint32_t deviceCount = 0;
    vkEnumeratePhysicalDevices(instance_, &deviceCount, nullptr);
    if (deviceCount == 0) {
        std::cerr << "Failed to find GPUs with Vulkan support" << std::endl;
        return false;
    }
    std::vector<VkPhysicalDevice> devices(deviceCount);
    vkEnumeratePhysicalDevices(instance_, &deviceCount, devices.data());

    for (const auto& dev : devices) {
        VkPhysicalDeviceProperties props;
        vkGetPhysicalDeviceProperties(dev, &props);
        // For now pick the first discrete or any device; you can improve selection
        VkPhysicalDeviceFeatures features;
        vkGetPhysicalDeviceFeatures(dev, &features);
        physical_ = dev;
        break;
    }
    return physical_ != VK_NULL_HANDLE;
}

bool GraphicsVulkan::CreateLogicalDevice()
{
    uint32_t queueFamilyCount = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(physical_, &queueFamilyCount, nullptr);
    std::vector<VkQueueFamilyProperties> queueFamilies(queueFamilyCount);
    vkGetPhysicalDeviceQueueFamilyProperties(physical_, &queueFamilyCount, queueFamilies.data());

    int graphicsFamily = -1;
    for (uint32_t i = 0; i < queueFamilies.size(); ++i) {
        if (queueFamilies[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) {
            graphicsFamily = static_cast<int>(i);
            break;
        }
    }
    if (graphicsFamily < 0) return false;
    graphicsQueueFamily_ = static_cast<uint32_t>(graphicsFamily);

    float queuePriority = 1.0f;
    VkDeviceQueueCreateInfo queueCreateInfo{};
    queueCreateInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
    queueCreateInfo.queueFamilyIndex = graphicsQueueFamily_;
    queueCreateInfo.queueCount = 1;
    queueCreateInfo.pQueuePriorities = &queuePriority;

    VkPhysicalDeviceFeatures deviceFeatures{};
    deviceFeatures.samplerAnisotropy = VK_TRUE;

    VkDeviceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    createInfo.pQueueCreateInfos = &queueCreateInfo;
    createInfo.queueCreateInfoCount = 1;
    createInfo.pEnabledFeatures = &deviceFeatures;

    const char* deviceExtensions[] = { VK_KHR_SWAPCHAIN_EXTENSION_NAME };
    createInfo.enabledExtensionCount = 1;
    createInfo.ppEnabledExtensionNames = deviceExtensions;

    if (vkCreateDevice(physical_, &createInfo, nullptr, &device_) != VK_SUCCESS) {
        std::cerr << "Failed to create logical device" << std::endl;
        return false;
    }
    vkGetDeviceQueue(device_, graphicsQueueFamily_, 0, &graphicsQueue_);
    return true;
}
