#pragma once
#include <vulkan/vulkan.h>
#include <vector>

struct FrameResources {
    VkCommandBuffer commandBuffer = VK_NULL_HANDLE;
    VkSemaphore imageAvailable = VK_NULL_HANDLE;
    VkSemaphore renderFinished = VK_NULL_HANDLE;
    VkFence inFlightFence = VK_NULL_HANDLE;
    VkFramebuffer framebuffer = VK_NULL_HANDLE;
};

class VulkanSwapchain {
public:
    VulkanSwapchain(VkDevice device, VkPhysicalDevice physical, VkSurfaceKHR surface, uint32_t graphicsQueueFamily);
    ~VulkanSwapchain();

    VkExtent2D GetExtent() const { return extent_; }
    VkFormat GetFormat() const { return format_; }
    uint32_t GetImageCount() const { return static_cast<uint32_t>(images_.size()); }

    VkImage GetImage(uint32_t index) const { return images_[index]; }
    VkImageView GetImageView(uint32_t index) const { return imageViews_[index]; }

    // Acquire next image (wrapper)
    VkResult AcquireNextImage(uint64_t timeout, VkSemaphore imageAvailable, uint32_t* imageIndex);

    void Recreate(uint32_t width, uint32_t height);

private:
    void CreateSwapchain();
    void CreateImageViews();
    void CreateFrameResources();

    VkDevice device_;
    VkPhysicalDevice physical_;
    VkSurfaceKHR surface_;
    uint32_t graphicsQueueFamily_;

    VkSwapchainKHR swapchain_ = VK_NULL_HANDLE;
    std::vector<VkImage> images_;
    std::vector<VkImageView> imageViews_;
    VkFormat format_;
    VkExtent2D extent_;
    std::vector<FrameResources> frames_;
};
