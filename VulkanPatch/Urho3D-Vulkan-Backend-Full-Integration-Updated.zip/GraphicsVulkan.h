        #pragma once
        #include "../Graphics.h"
#include <vulkan/vulkan.h>
#include <unordered_map>
#include <memory>

class VulkanSwapchain;
class VulkanRenderPass;
class ShaderCompiler;
class VulkanPipeline;
class BufferVulkan;
class TextureVulkan;

class GraphicsVulkan : public Graphics
{
public:
    GraphicsVulkan();
    ~GraphicsVulkan() override;

    bool Initialize(bool enableValidation = true);
    void Shutdown() override;

    bool BeginFrame() override;
    void EndFrame() override;

    // Material/pipeline helper
    VulkanPipeline* GetPipelineForMaterial(class Material* material);

    // Expose instance/device for other subsystems
    VkInstance GetInstance() const { return instance_; }
    VkDevice GetDevice() const { return device_; }
    VkPhysicalDevice GetPhysicalDevice() const { return physical_; }

private:
    bool CreateInstance(bool enableValidation);
    bool PickPhysicalDevice();
    bool CreateLogicalDevice();
    bool CreateSurfaceFromUrho(); // calls back into Urho3D to create VkSurfaceKHR

    VkInstance instance_ = VK_NULL_HANDLE;
    VkPhysicalDevice physical_ = VK_NULL_HANDLE;
    VkDevice device_ = VK_NULL_HANDLE;
    VkQueue graphicsQueue_ = VK_NULL_HANDLE;
    uint32_t graphicsQueueFamily_ = UINT32_MAX;

    VkSurfaceKHR surface_ = VK_NULL_HANDLE;

    std::unique_ptr<VulkanSwapchain> swapchain_;
    std::unique_ptr<VulkanRenderPass> renderPass_;
    std::unique_ptr<ShaderCompiler> shaderCompiler_;

    std::unordered_map<size_t, VulkanPipeline*> pipelineCache_;
};
