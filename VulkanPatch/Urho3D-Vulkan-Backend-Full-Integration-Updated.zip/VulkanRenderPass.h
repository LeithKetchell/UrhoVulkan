#pragma once
#include <vulkan/vulkan.h>
#include <vector>

struct RenderPassInfo {
    VkRenderPass renderPass = VK_NULL_HANDLE;
    VkFramebuffer framebuffer = VK_NULL_HANDLE;
    VkExtent2D extent = {0,0};
};

class VulkanRenderPass {
public:
    VulkanRenderPass(VkDevice device);
    ~VulkanRenderPass();

    bool CreateForwardPass(VkFormat colorFormat, VkFormat depthFormat, VkExtent2D extent);
    bool CreateDeferredPass(VkFormat colorFormat, VkFormat depthFormat, VkExtent2D extent);
    bool CreateShadowPass(VkExtent2D extent);
    bool CreatePostProcessPass(VkFormat colorFormat, VkExtent2D extent);

    RenderPassInfo& GetForwardPass() { return forward_; }
    RenderPassInfo& GetDeferredPass() { return deferred_; }

private:
    VkDevice device_;
    RenderPassInfo forward_;
    RenderPassInfo deferred_;
    RenderPassInfo shadow_;
    RenderPassInfo postProcess_;

    VkImage depthImage_ = VK_NULL_HANDLE;
    VkDeviceMemory depthMemory_ = VK_NULL_HANDLE;
    VkImageView depthView_ = VK_NULL_HANDLE;

    bool CreateDepthResources(VkFormat depthFormat, VkExtent2D extent);
};
